Hey there!

Hope you make good use of this pack. You can use all these assets in any project you want to (be it commercial or not).All of the assets are in the public domain under Creative Commons 0 (CC0)

In this pack you will find over 500 buttons including:

Xbox 360 Controller
Xbox One Controller + Diagram
Xbox Series X Controller + Diagram
Play Station 3 Controller
Play Station 4 Controller + Diagram
Play Station 5 Controller + Diagram
Play Station Move
PS Vita
Google Stadia Controller
Amazon Luna Controller
Vive Controller
Oculus Controllers & Remote
Wii Controller
Wii U Controller
Nintentdo Switch
Steam Controller (Updated to commercial version)
Ouya
Keyboard and mouse buttons (Both in dark and light variants including blanks)
Directional arrows for thumb sticks and movement keys
Touch Screen Gestures

----------------------------------

I am "Nicolae (Xelu) Berbece", I'm responsible for the development studio "Those Awesome Guys", developers of "Move or Die" and publishers of "Monster Prom".

You can contact me at nick@thoseawesomeguys.com or @xelubest

Feel free to credit me in case you use anything in this pack, but don't worry, I won't mind if you don't. ;)

Please share this pack with other fellow developers in need of such assets! In the spirit of good old chain mail, if you share this pack with 5 fellow devs, your game's steam review score will rise by 7% and a notable twitch streamer will pick it up for their stream.

Keep making awesome things!!!

~Nick



Here is a semi-regularly-updated list of games using these prompts:
----------------------------
Mega Man Legacy
Hunt: Showdown
Outter Wilds
Slay The Spire
A hat in Time
Forager
Wonder Boy the dragon's trap
Postal 2
Postal Redux
RWBY
PikuNiku
Shadow Warrior 2
Tiny Metal
Aztez
Disney Afternoon
Heat Signature
Turbo Dismount
Black Future 88
Fallen Legion
Fru
Blockships
20XX
Furi
Mike Dies
Snake Pass
Danger Scavenger
Roboquest
Rive
Faerie Afterlight
Obduction
Fractal Fall
Guild of Ascension
Avaria VS
Blast Zone! Tournament
100ft Robot Golf
Sockventure
Spellbreak
Zombie Rollerz
B.O.O.M . - You Win
Battle Chef Brigade
De Blob
Phantom Brigade
Wytchwood
Mulaka
Airheart - Tales of broken wings
Redirection
Pull Stay
Death Pedal
Defender's Quest
Akuto "Mad World"
Project Mobius
Whispering Willows
Vostok Inc.
Divine commander
Sbirz
Grashers
Remnants of Naezith
Mothergunship
Roundabout
Hunter of the Disowned
Cosmos Quickstop
West of Dead
Tune Tank
Rain on your Parade
Infinite Adventures
Arena 3D
Chroma Vaders
Hoverloop
Wrestling Revolution 3D
Altero
Super Comboman
Disc Jam
Cooking Simulator
Jelly is Sticky
The Hatching
World to the West
Mayan Death Robots
Sentris
Carto
Unbox
Fort Triumph
Insane Robots
Super Daryl Deluxe
Induction
Pawarumi
The Flock
Binary Trigger
Fractal Space
Deputy dangle
Bubsy: The Woolies Strike Back
Tumblestone
The chronicles of Kyra
Ghost Knight Victis
Solbrain Knight of Darkness
SSMP
Distance
Idarb
Earthlock
Everspace
Pylon Rogue
The Church in the darkness
Sword n' Board